export const PRIMARY_CUSTOM_DOMAIN = 'findit.zone.id';
export const PRIMARY_DOMAIN = PRIMARY_CUSTOM_DOMAIN;
export const DOMAIN_STATUS_LABEL = 'Custom domain ready';
export const DOMAIN_HELP_TEXT = 'Jika custom domain belum terbuka, pastikan DNS mengarah ke deployment Vercel dan rewrite SPA sudah aktif.';
