export const ABOUT_SECTION_BADGE = 'Tentang Tim FindIt';
export const ABOUT_ADMIN_NOTE = 'Konten bagian tentang dan tim dapat dikelola langsung dari Admin Console.';
