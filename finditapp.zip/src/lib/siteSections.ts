export const navSectionMap = {
  Beranda: { slug: 'beranda', target: 'home' },
  Laporan: { slug: 'laporan', target: 'laporan' },
  Kategori: { slug: 'kategori', target: 'kategori' },
  Tentang: { slug: 'tentang', target: 'tentang' },
  Bantuan: { slug: 'bantuan', target: 'bantuan' }
} as const;

export type NavSectionLabel = keyof typeof navSectionMap;
