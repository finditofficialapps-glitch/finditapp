export const mobileNavItems = [
  { label: 'Beranda', href: '#home' },
  { label: 'Laporan', href: '#laporan' },
  { label: 'Kategori', href: '#kategori' },
  { label: 'Tentang', href: '#tentang' },
  { label: 'Bantuan', href: '#bantuan' }
];

export const navSectionMap = {
  Beranda: { slug: 'beranda', target: 'home' },
  Laporan: { slug: 'laporan', target: 'laporan' },
  Kategori: { slug: 'kategori', target: 'kategori' },
  Tentang: { slug: 'tentang', target: 'tentang' },
  Bantuan: { slug: 'bantuan', target: 'bantuan' }
} as const;

export type NavSectionLabel = keyof typeof navSectionMap;

export const shortcutSlugs = {
  'Cara Melapor': 'cara-melapor',
  'Aturan Komunitas': 'aturan-komunitas',
  'Tips Keamanan': 'tips-keamanan',
  'Pusat Bantuan': 'pusat-bantuan'
} as const;
