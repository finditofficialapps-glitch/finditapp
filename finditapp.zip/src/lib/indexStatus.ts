export const HAS_INDEX_HTML = true;
export const INDEX_HTML_ROLE = 'Vite SPA entry point for FindIt. Vercel rewrites /admin to this file so React can render the admin dashboard.';
