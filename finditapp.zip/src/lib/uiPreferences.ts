export const SHOW_PROFILE_SYNC_LABEL = false;
