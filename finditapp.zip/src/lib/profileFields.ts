export const editableProfileFields = [
  { key: 'full_name', label: 'Nama lengkap', type: 'text' },
  { key: 'whatsapp', label: 'WhatsApp', type: 'tel' },
  { key: 'avatar_url', label: 'Foto profil / Avatar URL', type: 'url' },
  { key: 'bio', label: 'Bio', type: 'textarea' }
] as const;
