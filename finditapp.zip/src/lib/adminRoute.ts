export const ADMIN_ROUTE_PATH = '/admin';
export const ADMIN_ROUTE_REWRITE_NOTE = 'Vercel rewrite must send /admin to /index.html so the React admin dashboard can render.';
