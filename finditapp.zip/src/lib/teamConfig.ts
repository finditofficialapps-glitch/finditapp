export const TEAM_SECTION_TITLE = 'Tim Kami';
export const TEAM_SECTION_DESCRIPTION = 'Kenali tim operasional dan keamanan komunitas FindIt yang membantu menjaga laporan tetap aman, rapi, dan terpercaya.';
