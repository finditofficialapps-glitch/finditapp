export type WhatsAppReport = {
  title: string;
  status: string;
  category: string;
  location: string;
  province: string;
  reporter_name?: string;
};

export function buildWhatsAppMessage(report: WhatsAppReport) {
  const intro = report.status === 'Hilang'
    ? 'Halo, saya melihat laporan barang hilang Anda di FindIt.'
    : report.status === 'Ditemukan'
      ? 'Halo, saya melihat laporan barang ditemukan Anda di FindIt.'
      : 'Halo, saya melihat laporan barang di FindIt.';

  return [
    intro,
    '',
    `Barang: ${report.title}`,
    `Status: ${report.status}`,
    `Kategori: ${report.category}`,
    `Lokasi: ${report.location}, ${report.province}`,
    '',
    'Saya ingin mengonfirmasi informasi terkait barang tersebut.',
    'Mohon balas pesan ini jika masih tersedia/masih relevan.',
    '',
    'Catatan keamanan FindIt:',
    '- Saya tidak akan meminta OTP, PIN, password, atau data sensitif.',
    '- Jika perlu bertemu, mari pilih tempat publik yang aman.',
    '',
    'Terima kasih.'
  ].join('\n');
}

export function buildWhatsAppUrl(phone: string, report: WhatsAppReport) {
  const normalized = phone.startsWith('62') ? phone : `62${phone.replace(/^0/, '')}`;
  return `https://wa.me/${normalized}?text=${encodeURIComponent(buildWhatsAppMessage(report))}`;
}
