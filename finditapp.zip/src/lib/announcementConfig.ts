export const ANNOUNCEMENT_BAR_LABEL = 'Announcement';
export const ANNOUNCEMENT_FALLBACK_MESSAGE = 'Waspada scam: jangan pernah membagikan OTP, PIN, password, atau melakukan transfer sebelum verifikasi barang.';
export const ANNOUNCEMENT_MOBILE_SPEED_SECONDS = 28;
export const ANNOUNCEMENT_DESKTOP_SPEED_SECONDS = 36;
