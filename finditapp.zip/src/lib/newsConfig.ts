export const NEWS_SECTION_TITLE = 'Info & Berita FindIt';
export const NEWS_SECTION_DESCRIPTION = 'Informasi resmi, pembaruan fitur, dan edukasi keamanan komunitas yang dikelola dari Admin Console.';
