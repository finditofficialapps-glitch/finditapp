export const AUTH_EMAIL_PLACEHOLDER = 'Email';
export const AUTH_PASSWORD_PLACEHOLDER = 'Typing...';
export const AUTH_AUTOFILL_ENABLED = false;
