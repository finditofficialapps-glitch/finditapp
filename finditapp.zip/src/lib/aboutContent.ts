export const ABOUT_FEATURES = [
  'Verifikasi profile dan kontak pelapor untuk membangun kepercayaan komunitas.',
  'Moderasi laporan oleh admin whitelist agar data tetap aman dan relevan.',
  'Filter nasional 38 provinsi untuk mempercepat pencarian barang.',
  'Integrasi WhatsApp resmi untuk komunikasi langsung tanpa membagikan data sensitif.'
];

export const ABOUT_PROMISE = 'FindIt dibangun sebagai infrastruktur komunitas modern untuk membantu barang hilang kembali ke pemiliknya secara aman, cepat, dan transparan.';
