export const HIDE_ADMIN_CONSOLE_FOR_NON_WHITELISTED_USERS = true;
export const ADMIN_VISIBILITY_RULE = 'Admin Console links are visible only when the signed-in email exists in the admins whitelist table.';
