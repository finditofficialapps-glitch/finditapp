export const AUTH_SECURITY_NOTICE = 'FindIt tidak pernah menyimpan, menampilkan, atau membagikan kata sandi. Password dikirim langsung ke Supabase Auth melalui koneksi aman dan tidak pernah dikembalikan ke frontend maupun admin.';

export const PASSWORD_FIELD_PROPS = {
  autoComplete: 'current-password',
  spellCheck: false,
  autoCorrect: 'off',
  autoCapitalize: 'none'
} as const;

export const EMAIL_FIELD_PROPS = {
  autoComplete: 'email',
  spellCheck: false,
  autoCorrect: 'off',
  autoCapitalize: 'none'
} as const;
