export const NAVIGATION_MODE = 'direct-scroll';
export const SHOW_NAVIGATION_MODAL = false;

export const sectionDescriptions = {
  home: 'Mulai dari ringkasan platform, statistik komunitas, dan tombol cepat untuk membuat laporan.',
  laporan: 'Telusuri laporan barang hilang, ditemukan, dan dikembalikan dengan pencarian serta filter lengkap.',
  kategori: 'Pilih kategori populer agar pencarian barang lebih cepat dan relevan.',
  tentang: 'Pelajari misi FindIt sebagai platform komunitas barang hilang dan ditemukan di Indonesia.',
  bantuan: 'Baca panduan keamanan, aturan komunitas, dan pusat bantuan pengguna.'
} as const;
