type AboutContent = {
  id?: number;
  hero_title?: string;
  description?: string;
  mission?: string;
};

type TeamMember = {
  id: number;
  name: string;
  role: string;
  bio: string;
  photo_url: string;
  sort_order: number;
};

export default function AboutTeamSection({ about, team }: { about: AboutContent | null; team: TeamMember[] }) {
  return <section id="tentang" className="scroll-mt-28 mt-12 overflow-hidden rounded-[2rem] bg-slate-950 text-white shadow-2xl">
    <div className="grid gap-8 p-8 lg:grid-cols-[0.9fr_1.1fr] lg:p-10">
      <div>
        <p className="text-xs font-bold uppercase tracking-[0.28em] text-blue-300">Tentang FindIt</p>
        <h2 className="mt-4 text-4xl font-black tracking-tight md:text-5xl">{about?.hero_title || 'Tim kami membangun ekosistem aman untuk barang hilang dan ditemukan.'}</h2>
        <p className="mt-5 text-base leading-8 text-slate-300">{about?.description || 'FindIt dikelola oleh tim komunitas, moderator, dan relawan digital yang berfokus pada keamanan, verifikasi, serta kemudahan komunikasi antar pengguna di seluruh Indonesia.'}</p>
        <div className="mt-6 rounded-3xl border border-white/10 bg-white/10 p-5 backdrop-blur">
          <p className="text-sm font-black uppercase tracking-[0.2em] text-emerald-300">Misi</p>
          <p className="mt-3 leading-7 text-slate-200">{about?.mission || 'Misi kami adalah mempercepat proses menemukan dan mengembalikan barang dengan teknologi komunitas yang aman, transparan, dan mudah digunakan.'}</p>
        </div>
      </div>
      <div>
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.25em] text-violet-300">Tim Kami</p>
            <h3 className="mt-2 text-2xl font-black">Operasional, keamanan, dan produk</h3>
          </div>
        </div>
        <div className="mt-5 grid gap-4 md:grid-cols-3">
          {team.map((member) => <article key={member.id} className="rounded-[1.5rem] border border-white/10 bg-white/10 p-4 backdrop-blur">
            <img src={member.photo_url || 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=500&q=80'} className="h-36 w-full rounded-2xl object-cover" />
            <h4 className="mt-4 font-black">{member.name}</h4>
            <p className="mt-1 text-sm font-bold text-blue-200">{member.role}</p>
            <p className="mt-3 text-sm leading-6 text-slate-300">{member.bio}</p>
          </article>)}
        </div>
      </div>
    </div>
  </section>;
}
