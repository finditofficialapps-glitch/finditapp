import { ExternalLink } from 'lucide-react';
import { NEWS_SECTION_DESCRIPTION, NEWS_SECTION_TITLE } from '../lib/newsConfig';

export type SiteNewsCard = {
  id: number;
  title: string;
  excerpt: string;
  body: string;
  category: string;
  image_url: string;
  published: boolean;
  link_url?: string;
  link_label?: string;
  created_at: string;
};

export default function NewsSection({ news }: { news: SiteNewsCard[] }) {
  return <section className="mt-12 rounded-[2rem] bg-white p-6 shadow-[0_18px_60px_rgba(15,23,42,0.06)]">
    <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
      <div>
        <p className="text-xs font-bold uppercase tracking-[0.25em] text-blue-600">Website Content</p>
        <h2 className="mt-2 text-3xl font-black text-slate-950">{NEWS_SECTION_TITLE}</h2>
        <p className="mt-2 max-w-2xl text-slate-500">{NEWS_SECTION_DESCRIPTION}</p>
      </div>
      <a href="/admin" className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-bold text-white">Kelola di Admin</a>
    </div>
    <div className="mt-6 -mx-2 flex snap-x gap-4 overflow-x-auto px-2 pb-3 [scrollbar-width:thin]">
      {news.map((item) => <article key={item.id} className="min-w-[280px] snap-start overflow-hidden rounded-[1.5rem] border border-slate-100 bg-slate-50 md:min-w-[340px] lg:min-w-[360px]">
        <img src={item.image_url || 'https://images.unsplash.com/photo-1495020689067-958852a7765e?auto=format&fit=crop&w=700&q=80'} className="h-44 w-full object-cover" />
        <div className="p-5">
          <span className="rounded-full bg-blue-100 px-3 py-1 text-xs font-bold text-blue-700">{item.category}</span>
          <h3 className="mt-3 text-lg font-black text-slate-950">{item.title}</h3>
          <p className="mt-2 line-clamp-2 text-sm leading-6 text-slate-500">{item.excerpt}</p>
          {item.link_url ? <a href={item.link_url} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-2 rounded-2xl bg-blue-600 px-4 py-2 text-sm font-bold text-white shadow-lg shadow-blue-600/20">{item.link_label || 'Baca selengkapnya'} <ExternalLink size={15}/></a> : <p className="mt-4 text-xs font-semibold text-slate-400">Info internal FindIt</p>}
        </div>
      </article>)}
    </div>
  </section>;
}
