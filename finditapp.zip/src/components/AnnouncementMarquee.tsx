import { AlertTriangle, ShieldCheck } from 'lucide-react';
import { ANNOUNCEMENT_BAR_LABEL, ANNOUNCEMENT_FALLBACK_MESSAGE } from '../lib/announcementConfig';

export type Announcement = {
  id: number;
  title: string;
  message: string;
  category: string;
  link_url?: string;
  active: boolean;
  priority: number;
};

export default function AnnouncementMarquee({ announcements }: { announcements: Announcement[] }) {
  const items = announcements.length ? announcements : [{ id: 0, title: 'Waspada Scam', message: ANNOUNCEMENT_FALLBACK_MESSAGE, category: 'Keamanan', active: true, priority: 1 }];
  const repeated = [...items, ...items, ...items];
  return <div className="border-b border-amber-200 bg-gradient-to-r from-amber-50 via-orange-50 to-rose-50 text-slate-900">
    <div className="flex items-center gap-3 overflow-hidden px-4 py-2 lg:px-8">
      <div className="z-10 flex shrink-0 items-center gap-2 rounded-full bg-slate-950 px-3 py-1.5 text-xs font-black uppercase tracking-[0.16em] text-white shadow-lg">
        <ShieldCheck size={14} /> {ANNOUNCEMENT_BAR_LABEL}
      </div>
      <div className="relative min-w-0 flex-1 overflow-hidden">
        <div className="marquee-track flex w-max items-center gap-8 whitespace-nowrap">
          {repeated.map((item, index) => <a key={`${item.id}-${index}`} href={item.link_url || '#bantuan'} className="inline-flex items-center gap-2 text-sm font-bold text-slate-700 hover:text-rose-600">
            <AlertTriangle size={15} className="text-amber-600" />
            <span className="rounded-full bg-white/80 px-2 py-0.5 text-xs text-amber-700 ring-1 ring-amber-200">{item.category}</span>
            <span>{item.title}: {item.message}</span>
          </a>)}
        </div>
      </div>
    </div>
  </div>;
}
