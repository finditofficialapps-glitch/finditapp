import { Linkedin } from 'lucide-react';

export type TeamMember = {
  id: number;
  name: string;
  role: string;
  bio: string;
  photo_url: string;
  linkedin_url?: string;
  active: boolean;
  sort_order: number;
};

export default function TeamSection({ team }: { team: TeamMember[] }) {
  return <section className="mt-8 rounded-[2rem] bg-white p-6 text-slate-900 shadow-[0_18px_60px_rgba(15,23,42,0.06)]">
    <div className="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
      <div>
        <p className="text-xs font-bold uppercase tracking-[0.25em] text-violet-600">Tim Kami</p>
        <h2 className="mt-2 text-3xl font-black tracking-tight text-slate-950">Orang-orang di balik FindIt</h2>
        <p className="mt-2 max-w-2xl text-slate-500">Tim operasional, keamanan, dan komunitas yang menjaga FindIt tetap aman, responsif, dan bermanfaat untuk Indonesia.</p>
      </div>
    </div>
    <div className="mt-6 grid gap-4 md:grid-cols-3">
      {team.map((member) => <article key={member.id} className="group overflow-hidden rounded-[1.75rem] border border-slate-100 bg-slate-50 transition hover:-translate-y-1 hover:shadow-xl">
        <div className="relative h-64 overflow-hidden">
          <img src={member.photo_url || 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=700&q=80'} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/80 to-transparent p-5 text-white">
            <h3 className="text-xl font-black">{member.name}</h3>
            <p className="text-sm font-semibold text-blue-200">{member.role}</p>
          </div>
        </div>
        <div className="p-5">
          <p className="text-sm leading-6 text-slate-600">{member.bio}</p>
          {member.linkedin_url && <a href={member.linkedin_url} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-2 rounded-2xl bg-slate-950 px-4 py-2 text-sm font-bold text-white"><Linkedin size={16}/> Profil profesional</a>}
        </div>
      </article>)}
    </div>
  </section>;
}
