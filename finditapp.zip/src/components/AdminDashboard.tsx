import { FormEvent, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, BarChart3, CheckCircle2, ChevronRight, ClipboardList, FileText, Info, LayoutDashboard, Lock, LogOut, Megaphone, Search, Settings, ShieldCheck, Trash2, UserCog, UsersRound } from 'lucide-react';
import supabase from '../lib/supabase';
import { editableProfileFields } from '../lib/profileFields';

type SessionUser = { email?: string; user_metadata?: { full_name?: string; avatar_url?: string } } | null;
type Admin = { id: number; email: string; role: string; created_at: string };
type Report = { id: number; title: string; description: string; category: string; location: string; province: string; status: 'Hilang' | 'Ditemukan' | 'Dikembalikan'; reporter_name: string; reporter_email?: string; whatsapp: string; image_url: string; created_at: string; reporter_avatar?: string; reporter_profile_name?: string };
type AppUser = { id: number; email: string; full_name: string; avatar_url: string; whatsapp: string; bio: string; reports_count: number; is_admin: boolean; admin_role?: string | null; created_at: string };
type AppSetting = { id: number; key: string; value: string; updated_at?: string };
type SiteNews = { id: number; title: string; excerpt: string; body: string; category: string; image_url: string; published: boolean; author_email?: string; created_at: string; updated_at?: string; link_url?: string; link_label?: string };
type Announcement = { id: number; title: string; message: string; category: string; link_url: string; active: boolean; priority: number; author_email?: string; created_at: string; updated_at?: string };
type AboutContent = Record<string, string>;
type TeamMember = { id: number; name: string; role: string; bio: string; photo_url: string; linkedin_url?: string; active: boolean; sort_order: number };

type TabKey = 'dashboard' | 'reports' | 'users' | 'news' | 'announcements' | 'about' | 'whitelist' | 'settings';

const tabs: { key: TabKey; label: string; icon: any; description: string }[] = [
  { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, description: 'Ringkasan performa dan status komunitas.' },
  { key: 'reports', label: 'Laporan', icon: ClipboardList, description: 'Moderasi laporan hilang, ditemukan, dan dikembalikan.' },
  { key: 'users', label: 'User', icon: UsersRound, description: 'Pantau profil pengguna dan aktivitas laporan.' },
  { key: 'news', label: 'Info/Berita', icon: FileText, description: 'Kelola info dan berita yang tampil di halaman utama.' },
  { key: 'announcements', label: 'Announcement', icon: Megaphone, description: 'Kelola running text keamanan di navbar website utama.' },
  { key: 'about', label: 'Tentang', icon: Info, description: 'Kelola konten Tentang dan Tim Kami di halaman utama.' },
  { key: 'whitelist', label: 'Admin Whitelist', icon: ShieldCheck, description: 'Kelola akses admin berbasis email.' },
  { key: 'settings', label: 'Pengaturan', icon: Settings, description: 'Konfigurasi operasional platform.' }
];

function Avatar({ src, name }: { src?: string; name?: string }) {
  return <div className="grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-full bg-gradient-to-br from-rose-500 to-violet-600 p-[2px]"><div className="grid h-full w-full place-items-center overflow-hidden rounded-full bg-white text-sm font-black text-slate-800">{src ? <img src={src} className="h-full w-full object-cover" /> : (name || 'U').charAt(0).toUpperCase()}</div></div>;
}

function Metric({ label, value, icon: Icon, tone }: { label: string; value: number | string; icon: any; tone: string }) {
  return <div className="rounded-3xl border border-slate-100 bg-white p-5 shadow-[0_18px_60px_rgba(15,23,42,0.06)]"><div className="flex items-center justify-between"><div><p className="text-sm font-semibold text-slate-500">{label}</p><p className="mt-2 text-3xl font-black tracking-tight text-slate-950">{typeof value === 'number' ? value.toLocaleString('id-ID') : value}</p></div><div className={`grid h-12 w-12 place-items-center rounded-2xl ${tone}`}><Icon size={22}/></div></div></div>;
}

export default function AdminDashboard({ user, token, onLogin }: { user: SessionUser; token: string; onLogin: () => void }) {
  const [active, setActive] = useState<TabKey>('dashboard');
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [currentAdmin, setCurrentAdmin] = useState<Admin | null>(null);
  const [reports, setReports] = useState<Report[]>([]);
  const [users, setUsers] = useState<AppUser[]>([]);
  const [settings, setSettings] = useState<AppSetting[]>([]);
  const [news, setNews] = useState<SiteNews[]>([]);
  const [newsForm, setNewsForm] = useState({ title: '', excerpt: '', body: '', category: 'Info', image_url: '', link_url: '', link_label: 'Baca selengkapnya', published: true });
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [announcementForm, setAnnouncementForm] = useState({ title: '', message: '', category: 'Keamanan', link_url: '', active: true, priority: 1 });
  const [aboutContent, setAboutContent] = useState<AboutContent>({});
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [teamForm, setTeamForm] = useState({ name: '', role: '', bio: '', photo_url: '', linkedin_url: '', active: true, sort_order: 10 });
  const [editingUser, setEditingUser] = useState<AppUser | null>(null);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('admin');
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [savingSettings, setSavingSettings] = useState(false);

  const authHeaders = { Authorization: `Bearer ${token}` };

  const loadAll = async () => {
    if (!token) { setLoading(false); return; }
    setLoading(true);
    setError('');
    const [adminRes, reportRes, userRes, settingRes, newsRes, announcementRes, aboutRes] = await Promise.all([
      fetch('/api/admins', { headers: authHeaders }),
      fetch('/api/reports'),
      fetch('/api/admin-users', { headers: authHeaders }),
      fetch('/api/admin-settings', { headers: authHeaders }),
      fetch('/api/site-news?all=true', { headers: authHeaders }),
      fetch('/api/announcements?all=true', { headers: authHeaders }),
      fetch('/api/about')
    ]);

    const adminData = await adminRes.json().catch(() => ({}));
    if (!adminRes.ok) {
      setError(adminData.error || 'Akses admin ditolak');
      setLoading(false);
      return;
    }

    const reportData = await reportRes.json().catch(() => []);
    const userData = await userRes.json().catch(() => []);
    const settingData = await settingRes.json().catch(() => []);
    const newsData = await newsRes.json().catch(() => []);
    const announcementData = await announcementRes.json().catch(() => []);
    const aboutData = await aboutRes.json().catch(() => ({}));
    setAdmins(adminData.admins || []);
    setCurrentAdmin(adminData.current || null);
    setReports(Array.isArray(reportData) ? reportData : []);
    setUsers(Array.isArray(userData) ? userData : []);
    setSettings(Array.isArray(settingData) ? settingData : []);
    setNews(Array.isArray(newsData) ? newsData : []);
    setAnnouncements(Array.isArray(announcementData) ? announcementData : []);
    setAboutContent(aboutData?.about ? { title: aboutData.about.hero_title || '', description: aboutData.about.description || '', mission: aboutData.about.mission || '' } : {});
    setTeamMembers(Array.isArray(aboutData?.team) ? aboutData.team : []);
    setLoading(false);
  };

  useEffect(() => { loadAll(); }, [token]);

  const stats = useMemo(() => ({
    total: reports.length,
    lost: reports.filter((r) => r.status === 'Hilang').length,
    found: reports.filter((r) => r.status === 'Ditemukan').length,
    returned: reports.filter((r) => r.status === 'Dikembalikan').length,
    users: users.length,
    admins: admins.length,
    news: news.filter((item) => item.published).length,
    announcements: announcements.filter((item) => item.active).length
  }), [reports, users, admins, news, announcements]);

  const filteredReports = reports.filter((report) => `${report.title} ${report.location} ${report.reporter_name}`.toLowerCase().includes(query.toLowerCase()));
  const filteredUsers = users.filter((item) => `${item.full_name} ${item.email}`.toLowerCase().includes(query.toLowerCase()));
  const filteredNews = news.filter((item) => `${item.title} ${item.excerpt} ${item.category}`.toLowerCase().includes(query.toLowerCase()));
  const filteredAnnouncements = announcements.filter((item) => `${item.title} ${item.message} ${item.category}`.toLowerCase().includes(query.toLowerCase()));

  const updateEditingUser = (key: keyof AppUser, value: string) => {
    if (!editingUser) return;
    setEditingUser({ ...editingUser, [key]: value });
  };

  const uploadEditingAvatar = (file?: File) => {
    if (!file || !editingUser) return;
    const reader = new FileReader();
    reader.onload = () => setEditingUser({ ...editingUser, avatar_url: String(reader.result) });
    reader.readAsDataURL(file);
  };

  const saveUserProfile = async (e: FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    const res = await fetch('/api/admin-users', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...authHeaders },
      body: JSON.stringify({
        id: editingUser.id,
        full_name: editingUser.full_name,
        avatar_url: editingUser.avatar_url,
        whatsapp: editingUser.whatsapp,
        bio: editingUser.bio
      })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) setError(data.error || 'Gagal mengubah profile user');
    else {
      setEditingUser(null);
      loadAll();
    }
  };

  const addAdmin = async (e: FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/admins', { method: 'POST', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify({ email, role }) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) setError(data.error || 'Gagal menambah admin');
    else { setEmail(''); setRole('admin'); loadAll(); }
  };

  const removeAdmin = async (id: number) => {
    if (!confirm('Hapus admin dari whitelist?')) return;
    await fetch('/api/admins', { method: 'DELETE', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify({ id }) });
    loadAll();
  };

  const markReturned = async (id: number) => {
    await fetch('/api/reports', { method: 'PUT', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify({ id, status: 'Dikembalikan' }) });
    loadAll();
  };

  const deleteReport = async (id: number) => {
    if (!confirm('Hapus laporan ini?')) return;
    await fetch('/api/reports', { method: 'DELETE', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify({ id }) });
    loadAll();
  };

  const setSettingValue = (key: string, value: string) => setSettings((prev) => prev.map((item) => item.key === key ? { ...item, value } : item));
  const saveSettings = async () => {
    setSavingSettings(true);
    const res = await fetch('/api/admin-settings', { method: 'PUT', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify({ settings: settings.map(({ key, value }) => ({ key, value })) }) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) setError(data.error || 'Gagal menyimpan pengaturan');
    else loadAll();
    setSavingSettings(false);
  };

  const saveNews = async (e: FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/site-news', { method: 'POST', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify(newsForm) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) setError(data.error || 'Gagal menyimpan berita');
    else {
      setNewsForm({ title: '', excerpt: '', body: '', category: 'Info', image_url: '', link_url: '', link_label: 'Baca selengkapnya', published: true });
      loadAll();
    }
  };

  const toggleNews = async (item: SiteNews) => {
    await fetch('/api/site-news', { method: 'PUT', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify({ id: item.id, published: !item.published }) });
    loadAll();
  };

  const deleteNews = async (id: number) => {
    if (!confirm('Hapus berita/info ini?')) return;
    await fetch('/api/site-news', { method: 'DELETE', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify({ id }) });
    loadAll();
  };

  const saveAnnouncement = async (e: FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/announcements', { method: 'POST', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify(announcementForm) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) setError(data.error || 'Gagal menyimpan announcement');
    else {
      setAnnouncementForm({ title: '', message: '', category: 'Keamanan', link_url: '', active: true, priority: 1 });
      loadAll();
    }
  };

  const toggleAnnouncement = async (item: Announcement) => {
    await fetch('/api/announcements', { method: 'PUT', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify({ id: item.id, active: !item.active }) });
    loadAll();
  };

  const deleteAnnouncement = async (id: number) => {
    if (!confirm('Hapus announcement ini?')) return;
    await fetch('/api/announcements', { method: 'DELETE', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify({ id }) });
    loadAll();
  };

  const saveAbout = async () => {
    setSavingSettings(true);
    const res = await fetch('/api/about', { method: 'PUT', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify({ type: 'about', hero_title: aboutContent.title, description: aboutContent.description, mission: aboutContent.mission }) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) setError(data.error || 'Gagal menyimpan konten tentang');
    else loadAll();
    setSavingSettings(false);
  };

  const saveTeam = async (e: FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/team', { method: 'POST', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify(teamForm) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) setError(data.error || 'Gagal menyimpan tim');
    else {
      setTeamForm({ name: '', role: '', bio: '', photo_url: '', linkedin_url: '', active: true, sort_order: 10 });
      loadAll();
    }
  };

  const toggleTeam = async (member: TeamMember) => {
    await fetch('/api/team', { method: 'PUT', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify({ id: member.id, active: !member.active }) });
    loadAll();
  };

  const deleteTeam = async (id: number) => {
    if (!confirm('Hapus anggota Tim Kami?')) return;
    await fetch('/api/team', { method: 'DELETE', headers: { 'Content-Type': 'application/json', ...authHeaders }, body: JSON.stringify({ id }) });
    loadAll();
  };

  if (!user) return <div className="min-h-screen bg-slate-950 p-6 text-white"><div className="mx-auto max-w-lg pt-24"><a href="/" className="text-slate-300">← Kembali ke FindIt</a><div className="mt-8 rounded-[2rem] border border-white/10 bg-white/10 p-8 shadow-2xl backdrop-blur"><Lock className="text-blue-300" size={42}/><h1 className="mt-4 text-3xl font-black">FindIt Admin Console</h1><p className="mt-3 text-slate-300">Masuk untuk membuka dashboard internal admin.</p><button onClick={onLogin} className="mt-6 rounded-2xl bg-white px-5 py-3 font-bold text-slate-950">Login Admin</button></div></div></div>;

  return <div className="min-h-screen bg-slate-100 text-slate-900">
    <header className="sticky top-0 z-30 border-b border-white/10 bg-slate-950 text-white">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 lg:px-8">
        <a href="/" className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-rose-500 to-violet-600 font-black">F</span><div><p className="font-black">FindIt Admin Console</p><p className="text-xs text-slate-400">Professional operations dashboard</p></div></a>
        <div className="flex items-center gap-3"><span className="hidden text-sm text-slate-300 md:block">{user.email}</span><button onClick={() => supabase.auth.signOut()} className="inline-flex items-center gap-2 rounded-2xl bg-white/10 px-4 py-2 text-sm font-bold hover:bg-white/15"><LogOut size={16}/> Logout</button></div>
      </div>
    </header>

    <div className="mx-auto grid max-w-7xl gap-6 px-4 py-6 lg:grid-cols-[280px_1fr] lg:px-8">
      <aside className="h-fit rounded-[2rem] border border-slate-200 bg-white p-3 shadow-[0_18px_60px_rgba(15,23,42,0.06)] lg:sticky lg:top-24">
        <div className="p-4"><p className="text-xs font-bold uppercase tracking-[0.25em] text-blue-600">Navigation</p><h2 className="mt-2 text-xl font-black">Admin Panel</h2></div>
        <div className="grid gap-1">{tabs.map((tab) => { const Icon = tab.icon; return <button key={tab.key} onClick={() => setActive(tab.key)} className={`flex items-center justify-between rounded-2xl px-4 py-3 text-left transition ${active === tab.key ? 'bg-slate-950 text-white shadow-lg shadow-slate-900/15' : 'text-slate-600 hover:bg-slate-50'}`}><span className="flex items-center gap-3 font-bold"><Icon size={18}/>{tab.label}</span><ChevronRight size={16}/></button>; })}</div>
        <div className="mt-4 rounded-3xl bg-blue-50 p-4 text-sm text-blue-800"><b>{currentAdmin?.role || 'admin'}</b><br/>Akses diverifikasi via whitelist email.</div>
      </aside>

      <main className="space-y-6">
        <section className="rounded-[2rem] bg-white p-6 shadow-[0_18px_60px_rgba(15,23,42,0.06)]">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between"><div><p className="text-xs font-bold uppercase tracking-[0.25em] text-blue-600">{tabs.find((tab) => tab.key === active)?.label}</p><h1 className="text-3xl font-black tracking-tight">{tabs.find((tab) => tab.key === active)?.description}</h1></div>{active !== 'settings' && <div className="flex items-center gap-3 rounded-2xl bg-slate-50 px-4 py-3"><Search className="text-slate-400" size={18}/><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Cari data admin..." className="bg-transparent outline-none"/></div>}</div>
        </section>

        {loading && <div className="rounded-[2rem] bg-white p-10 shadow-sm">Memuat dashboard admin...</div>}
        {error && <div className="rounded-[2rem] border border-rose-100 bg-white p-6 text-rose-700 shadow-sm"><AlertTriangle className="mb-2"/> {error}</div>}

        {!loading && !error && active === 'dashboard' && <section className="space-y-6"><div className="grid gap-4 md:grid-cols-3"><Metric label="Total Laporan" value={stats.total} icon={ClipboardList} tone="bg-blue-50 text-blue-600"/><Metric label="User Terdaftar" value={stats.users} icon={UsersRound} tone="bg-emerald-50 text-emerald-600"/><Metric label="Admin Aktif" value={stats.admins} icon={ShieldCheck} tone="bg-violet-50 text-violet-600"/><Metric label="Berita Published" value={stats.news} icon={FileText} tone="bg-cyan-50 text-cyan-600"/><Metric label="Hilang" value={stats.lost} icon={AlertTriangle} tone="bg-rose-50 text-rose-600"/><Metric label="Dikembalikan" value={stats.returned} icon={CheckCircle2} tone="bg-green-50 text-green-600"/></div><div className="grid gap-6 xl:grid-cols-2"><div className="rounded-[2rem] bg-white p-6 shadow-sm"><h3 className="text-xl font-black">Aktivitas laporan terbaru</h3><div className="mt-4 grid gap-3">{reports.slice(0, 5).map((report) => <div key={report.id} className="flex items-center justify-between rounded-2xl bg-slate-50 p-4"><div><p className="font-bold">{report.title}</p><p className="text-sm text-slate-500">{report.status} • {report.province}</p></div><span className="rounded-full bg-white px-3 py-1 text-xs font-bold text-slate-500">#{report.id}</span></div>)}</div></div><div className="rounded-[2rem] bg-white p-6 shadow-sm"><h3 className="text-xl font-black">Info/Berita di website utama</h3><div className="mt-4 grid gap-3">{news.slice(0, 4).map((item) => <div key={item.id} className="rounded-2xl bg-slate-50 p-4"><p className="font-bold">{item.title}</p><p className="mt-1 text-sm text-slate-500">{item.category} • {item.published ? 'Published' : 'Draft'}</p></div>)}</div></div></div></section>}

        {!loading && !error && active === 'reports' && <section className="grid gap-4">{filteredReports.map((report) => <article key={report.id} className="rounded-[2rem] bg-white p-5 shadow-sm"><div className="grid gap-4 md:grid-cols-[120px_1fr_auto]"><img src={report.image_url || 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=500&q=80'} className="h-28 w-full rounded-2xl object-cover"/><div><div className="flex flex-wrap gap-2"><span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold">{report.status}</span><span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700">{report.category}</span></div><h3 className="mt-3 text-xl font-black">{report.title}</h3><p className="mt-1 text-sm text-slate-500">{report.location}, {report.province} • {report.reporter_profile_name || report.reporter_name}</p></div><div className="flex flex-col gap-2"><button onClick={() => markReturned(report.id)} className="rounded-2xl bg-emerald-50 px-4 py-2 text-sm font-bold text-emerald-700">Tandai kembali</button><button onClick={() => deleteReport(report.id)} className="rounded-2xl bg-rose-50 px-4 py-2 text-sm font-bold text-rose-700"><Trash2 className="mr-1 inline" size={15}/> Hapus</button></div></div></article>)}</section>}

        {!loading && !error && active === 'users' && <section className="grid gap-6 xl:grid-cols-[1fr_420px]"><div className="rounded-[2rem] bg-white p-5 shadow-sm"><div className="grid gap-3">{filteredUsers.map((item) => <div key={item.id} className="flex flex-col gap-3 rounded-2xl border border-slate-100 p-4 md:flex-row md:items-center md:justify-between"><div className="flex items-center gap-3"><Avatar src={item.avatar_url} name={item.full_name || item.email}/><div><p className="font-black">{item.full_name || item.email}</p><p className="text-sm text-slate-500">{item.email}</p><p className="mt-1 line-clamp-2 text-xs text-slate-400">{item.bio || 'Belum ada bio'}</p></div></div><div className="flex flex-wrap gap-2"><span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold">{item.reports_count} laporan</span>{item.is_admin && <span className="rounded-full bg-violet-50 px-3 py-1 text-xs font-bold text-violet-700">{item.admin_role}</span>}<button onClick={() => setEditingUser(item)} className="rounded-full bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700"><UserCog className="mr-1 inline" size={13}/> Edit</button></div></div>)}</div></div><aside className="h-fit rounded-[2rem] bg-white p-6 shadow-sm xl:sticky xl:top-24"><h3 className="text-2xl font-black">Edit Profile User</h3><p className="mt-1 text-sm leading-6 text-slate-500">Admin dapat mengubah foto, nama, WhatsApp, dan bio user. Perubahan langsung tersinkron ke profile navbar dan kartu laporan.</p>{editingUser ? <form onSubmit={saveUserProfile} className="mt-5 space-y-4"><div className="flex items-center gap-4"><Avatar src={editingUser.avatar_url} name={editingUser.full_name || editingUser.email}/><div><p className="font-bold text-slate-900">{editingUser.email}</p><label className="mt-2 inline-flex cursor-pointer rounded-xl bg-slate-100 px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-200">Upload foto<input type="file" accept="image/*" className="hidden" onChange={(e) => uploadEditingAvatar(e.target.files?.[0])}/></label></div></div>{editableProfileFields.map((field) => field.type === 'textarea' ? <label key={field.key} className="block space-y-2"><span className="text-sm font-bold text-slate-700">{field.label}</span><textarea value={String(editingUser[field.key] || '')} onChange={(e) => updateEditingUser(field.key, e.target.value)} className="min-h-24 w-full rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/></label> : <label key={field.key} className="block space-y-2"><span className="text-sm font-bold text-slate-700">{field.label}</span><input type={field.type} value={String(editingUser[field.key] || '')} onChange={(e) => updateEditingUser(field.key, e.target.value)} className="w-full rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/></label>)}<div className="flex gap-2"><button className="flex-1 rounded-2xl bg-slate-950 px-5 py-3 font-bold text-white">Simpan</button><button type="button" onClick={() => setEditingUser(null)} className="flex-1 rounded-2xl border border-slate-200 px-5 py-3 font-bold text-slate-700">Batal</button></div></form> : <div className="mt-5 rounded-2xl bg-slate-50 p-5 text-sm text-slate-500">Pilih tombol <b>Edit</b> pada salah satu user untuk membuka pengaturan profile profesional.</div>}</aside></section>}

        {!loading && !error && active === 'news' && <section className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]"><form onSubmit={saveNews} className="h-fit rounded-[2rem] bg-white p-6 shadow-sm"><h3 className="text-2xl font-black">Tambah Info/Berita</h3><p className="mt-1 text-sm text-slate-500">Berita published otomatis tampil di halaman utama website.</p><div className="mt-5 grid gap-4"><input required value={newsForm.title} onChange={(e) => setNewsForm({ ...newsForm, title: e.target.value })} placeholder="Judul berita" className="rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><input required value={newsForm.excerpt} onChange={(e) => setNewsForm({ ...newsForm, excerpt: e.target.value })} placeholder="Ringkasan singkat" className="rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><textarea required value={newsForm.body} onChange={(e) => setNewsForm({ ...newsForm, body: e.target.value })} placeholder="Isi lengkap berita/info" className="min-h-28 rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><div className="grid gap-3 sm:grid-cols-2"><input value={newsForm.category} onChange={(e) => setNewsForm({ ...newsForm, category: e.target.value })} placeholder="Kategori" className="rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><select value={String(newsForm.published)} onChange={(e) => setNewsForm({ ...newsForm, published: e.target.value === 'true' })} className="rounded-2xl border border-slate-200 px-4 py-3"><option value="true">Published</option><option value="false">Draft</option></select></div><input value={newsForm.image_url} onChange={(e) => setNewsForm({ ...newsForm, image_url: e.target.value })} placeholder="URL gambar berita" className="rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><button className="rounded-2xl bg-blue-600 px-5 py-3 font-bold text-white">Publikasikan</button></div></form><div className="rounded-[2rem] bg-white p-5 shadow-sm"><h3 className="text-2xl font-black">Daftar Info/Berita</h3><div className="mt-5 grid gap-4">{filteredNews.map((item) => <article key={item.id} className="grid gap-4 rounded-2xl border border-slate-100 p-4 md:grid-cols-[120px_1fr_auto]"><img src={item.image_url || 'https://images.unsplash.com/photo-1495020689067-958852a7765e?auto=format&fit=crop&w=500&q=80'} className="h-24 w-full rounded-2xl object-cover"/><div><div className="flex flex-wrap gap-2"><span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700">{item.category}</span><span className={`rounded-full px-3 py-1 text-xs font-bold ${item.published ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>{item.published ? 'Published' : 'Draft'}</span></div><h4 className="mt-2 font-black">{item.title}</h4><p className="mt-1 line-clamp-2 text-sm text-slate-500">{item.excerpt}</p></div><div className="flex flex-col gap-2"><button onClick={() => toggleNews(item)} className="rounded-2xl bg-slate-100 px-4 py-2 text-sm font-bold text-slate-700">{item.published ? 'Jadikan Draft' : 'Publish'}</button><button onClick={() => deleteNews(item.id)} className="rounded-2xl bg-rose-50 px-4 py-2 text-sm font-bold text-rose-700"><Trash2 className="mr-1 inline" size={15}/> Hapus</button></div></article>)}</div></div></section>}

        {!loading && !error && active === 'announcements' && <section className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]"><form onSubmit={saveAnnouncement} className="h-fit rounded-[2rem] bg-white p-6 shadow-sm"><h3 className="text-2xl font-black">Tambah Announcement</h3><p className="mt-1 text-sm text-slate-500">Announcement aktif tampil sebagai running text dari kanan ke kiri di navbar utama.</p><div className="mt-5 grid gap-4"><input required value={announcementForm.title} onChange={(e) => setAnnouncementForm({ ...announcementForm, title: e.target.value })} placeholder="Judul: Waspada Scam" className="rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><textarea required value={announcementForm.message} onChange={(e) => setAnnouncementForm({ ...announcementForm, message: e.target.value })} placeholder="Pesan keamanan / scam / komunitas" className="min-h-28 rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><div className="grid gap-3 sm:grid-cols-3"><input value={announcementForm.category} onChange={(e) => setAnnouncementForm({ ...announcementForm, category: e.target.value })} placeholder="Kategori" className="rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><input type="number" value={announcementForm.priority} onChange={(e) => setAnnouncementForm({ ...announcementForm, priority: Number(e.target.value) })} placeholder="Prioritas" className="rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><select value={String(announcementForm.active)} onChange={(e) => setAnnouncementForm({ ...announcementForm, active: e.target.value === 'true' })} className="rounded-2xl border border-slate-200 px-4 py-3"><option value="true">Aktif</option><option value="false">Nonaktif</option></select></div><input value={announcementForm.link_url} onChange={(e) => setAnnouncementForm({ ...announcementForm, link_url: e.target.value })} placeholder="Link opsional" className="rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><button className="rounded-2xl bg-blue-600 px-5 py-3 font-bold text-white">Tampilkan di Navbar</button></div></form><div className="rounded-[2rem] bg-white p-5 shadow-sm"><h3 className="text-2xl font-black">Daftar Announcement</h3><div className="mt-5 grid gap-4">{filteredAnnouncements.map((item) => <article key={item.id} className="rounded-2xl border border-slate-100 p-4"><div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between"><div><div className="flex flex-wrap gap-2"><span className="rounded-full bg-amber-50 px-3 py-1 text-xs font-bold text-amber-700">{item.category}</span><span className={`rounded-full px-3 py-1 text-xs font-bold ${item.active ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>{item.active ? 'Aktif' : 'Nonaktif'}</span><span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700">Priority {item.priority}</span></div><h4 className="mt-2 font-black">{item.title}</h4><p className="mt-1 text-sm leading-6 text-slate-500">{item.message}</p></div><div className="flex shrink-0 gap-2"><button onClick={() => toggleAnnouncement(item)} className="rounded-2xl bg-slate-100 px-4 py-2 text-sm font-bold text-slate-700">{item.active ? 'Nonaktifkan' : 'Aktifkan'}</button><button onClick={() => deleteAnnouncement(item.id)} className="rounded-2xl bg-rose-50 px-4 py-2 text-sm font-bold text-rose-700"><Trash2 className="mr-1 inline" size={15}/> Hapus</button></div></div></article>)}</div></div></section>}

        {!loading && !error && active === 'about' && <section className="space-y-6"><div className="rounded-[2rem] bg-white p-6 shadow-sm"><div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between"><div><h3 className="text-2xl font-black">Pengaturan Tentang</h3><p className="mt-1 text-sm text-slate-500">Konten ini tampil saat pengguna klik menu Tentang di halaman utama.</p></div><button disabled={savingSettings || currentAdmin?.role !== 'superadmin'} onClick={saveAbout} className="rounded-2xl bg-slate-950 px-5 py-3 font-bold text-white disabled:opacity-50">{savingSettings ? 'Menyimpan...' : 'Simpan Tentang'}</button></div><div className="mt-6 grid gap-4"><label className="space-y-2"><span className="text-sm font-bold text-slate-700">Judul utama</span><input value={aboutContent.title || ''} onChange={(e) => setAboutContent({ ...aboutContent, title: e.target.value })} disabled={currentAdmin?.role !== 'superadmin'} className="w-full rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400 disabled:bg-slate-50"/></label><label className="space-y-2"><span className="text-sm font-bold text-slate-700">Deskripsi Tentang</span><textarea value={aboutContent.description || ''} onChange={(e) => setAboutContent({ ...aboutContent, description: e.target.value })} disabled={currentAdmin?.role !== 'superadmin'} className="min-h-28 w-full rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400 disabled:bg-slate-50"/></label><label className="space-y-2"><span className="text-sm font-bold text-slate-700">Misi</span><textarea value={aboutContent.mission || ''} onChange={(e) => setAboutContent({ ...aboutContent, mission: e.target.value })} disabled={currentAdmin?.role !== 'superadmin'} className="min-h-24 w-full rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400 disabled:bg-slate-50"/></label></div></div><div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]"><form onSubmit={saveTeam} className="h-fit rounded-[2rem] bg-white p-6 shadow-sm"><h3 className="text-2xl font-black">Tambah Tim Kami</h3><p className="mt-1 text-sm text-slate-500">Nama, jabatan, bio, dan foto ini langsung tampil di website utama.</p><div className="mt-5 grid gap-4"><input required value={teamForm.name} onChange={(e) => setTeamForm({ ...teamForm, name: e.target.value })} placeholder="Nama anggota tim" className="rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><input required value={teamForm.role} onChange={(e) => setTeamForm({ ...teamForm, role: e.target.value })} placeholder="Role / jabatan" className="rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><textarea value={teamForm.bio} onChange={(e) => setTeamForm({ ...teamForm, bio: e.target.value })} placeholder="Bio singkat" className="min-h-24 rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><input value={teamForm.photo_url} onChange={(e) => setTeamForm({ ...teamForm, photo_url: e.target.value })} placeholder="URL foto / avatar" className="rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><input value={teamForm.linkedin_url} onChange={(e) => setTeamForm({ ...teamForm, linkedin_url: e.target.value })} placeholder="Link profil opsional" className="rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><div className="grid gap-3 sm:grid-cols-2"><input type="number" value={teamForm.sort_order} onChange={(e) => setTeamForm({ ...teamForm, sort_order: Number(e.target.value) })} className="rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400"/><select value={String(teamForm.active)} onChange={(e) => setTeamForm({ ...teamForm, active: e.target.value === 'true' })} className="rounded-2xl border border-slate-200 px-4 py-3"><option value="true">Aktif</option><option value="false">Nonaktif</option></select></div><button className="rounded-2xl bg-blue-600 px-5 py-3 font-bold text-white">Tambah Tim</button></div></form><div className="rounded-[2rem] bg-white p-5 shadow-sm"><h3 className="text-2xl font-black">Daftar Tim Kami</h3><div className="mt-5 grid gap-4">{teamMembers.map((member) => <article key={member.id} className="grid gap-4 rounded-2xl border border-slate-100 p-4 md:grid-cols-[72px_1fr_auto]"><Avatar src={member.photo_url} name={member.name}/><div><div className="flex flex-wrap gap-2"><span className={`rounded-full px-3 py-1 text-xs font-bold ${member.active ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>{member.active ? 'Aktif' : 'Nonaktif'}</span><span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700">Urutan {member.sort_order}</span></div><h4 className="mt-2 font-black">{member.name}</h4><p className="text-sm font-semibold text-slate-500">{member.role}</p><p className="mt-1 line-clamp-2 text-sm text-slate-500">{member.bio}</p></div><div className="flex flex-col gap-2"><button onClick={() => setTeamForm({ name: member.name, role: member.role, bio: member.bio, photo_url: member.photo_url, linkedin_url: member.linkedin_url || '', active: member.active, sort_order: member.sort_order })} className="rounded-2xl bg-slate-100 px-4 py-2 text-sm font-bold text-slate-700">Salin/Edit</button><button onClick={() => toggleTeam(member)} className="rounded-2xl bg-blue-50 px-4 py-2 text-sm font-bold text-blue-700">{member.active ? 'Nonaktifkan' : 'Aktifkan'}</button><button onClick={() => deleteTeam(member.id)} className="rounded-2xl bg-rose-50 px-4 py-2 text-sm font-bold text-rose-700"><Trash2 className="mr-1 inline" size={15}/> Hapus</button></div></article>)}</div></div></div></section>}

        {!loading && !error && active === 'whitelist' && <section className="rounded-[2rem] bg-white p-6 shadow-sm"><div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between"><div><h3 className="text-2xl font-black">Admin Whitelist</h3><p className="mt-1 text-sm text-slate-500">Hanya email terdaftar yang bisa membuka admin console.</p></div>{currentAdmin?.role === 'superadmin' && <form onSubmit={addAdmin} className="flex flex-col gap-2 sm:flex-row"><input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="admin@domain.com" className="rounded-2xl border border-slate-200 px-4 py-3"/><select value={role} onChange={(e) => setRole(e.target.value)} className="rounded-2xl border border-slate-200 px-4 py-3"><option value="admin">admin</option><option value="superadmin">superadmin</option></select><button className="rounded-2xl bg-blue-600 px-5 py-3 font-bold text-white">Tambah</button></form>}</div><div className="mt-6 grid gap-3">{admins.map((admin) => <div key={admin.id} className="flex items-center justify-between rounded-2xl bg-slate-50 p-4"><div><p className="font-black">{admin.email}</p><p className="text-xs font-bold uppercase text-slate-400">{admin.role}</p></div>{currentAdmin?.role === 'superadmin' && currentAdmin.id !== admin.id && <button onClick={() => removeAdmin(admin.id)} className="rounded-xl bg-rose-50 p-2 text-rose-600"><Trash2 size={18}/></button>}</div>)}</div></section>}

        {!loading && !error && active === 'settings' && <section className="rounded-[2rem] bg-white p-6 shadow-sm"><div className="flex items-center justify-between"><div><h3 className="text-2xl font-black">Pengaturan Platform</h3><p className="mt-1 text-sm text-slate-500">Atur teks operasional yang dipakai tim admin.</p></div><button disabled={savingSettings || currentAdmin?.role !== 'superadmin'} onClick={saveSettings} className="rounded-2xl bg-slate-950 px-5 py-3 font-bold text-white disabled:opacity-50">{savingSettings ? 'Menyimpan...' : 'Simpan'}</button></div><div className="mt-6 grid gap-4">{settings.map((setting) => <label key={setting.key} className="space-y-2"><span className="text-sm font-bold text-slate-700">{setting.key}</span><input value={setting.value} onChange={(e) => setSettingValue(setting.key, e.target.value)} disabled={currentAdmin?.role !== 'superadmin'} className="w-full rounded-2xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-400 disabled:bg-slate-50"/></label>)}</div></section>}
      </main>
    </div>
  </div>;
}
