import supabase from './_supabase.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

async function requireAdmin(req, res) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) {
    res.status(401).json({ error: 'Unauthorized' });
    return null;
  }
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    res.status(401).json({ error: 'Invalid token' });
    return null;
  }
  const { data, error: adminError } = await supabase.from('admins').select('*').eq('email', user.email.toLowerCase()).limit(1);
  if (adminError || !data?.length) {
    res.status(403).json({ error: 'Admin access required' });
    return null;
  }
  return { user, admin: data[0] };
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const auth = await requireAdmin(req, res);
    if (!auth) return;

    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('app_settings')
        .select('*')
        .order('key', { ascending: true });
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'PUT') {
      if (auth.admin.role !== 'superadmin') return res.status(403).json({ error: 'Hanya superadmin yang dapat mengubah pengaturan' });
      const updates = Array.isArray(req.body?.settings) ? req.body.settings : [];
      if (!updates.length) return res.status(400).json({ error: 'Settings kosong' });

      const saved = [];
      for (const item of updates) {
        const key = String(item.key || '').trim();
        const value = String(item.value ?? '').trim();
        if (!key) continue;
        const { data: existing, error: findError } = await supabase.from('app_settings').select('id').eq('key', key).limit(1);
        if (findError) throw findError;
        if (existing?.length) {
          const { data, error } = await supabase.from('app_settings').update({ value, updated_at: new Date().toISOString() }).eq('key', key).select().single();
          if (error) throw error;
          saved.push(data);
        } else {
          const { data, error } = await supabase.from('app_settings').insert({ key, value }).select().single();
          if (error) throw error;
          saved.push(data);
        }
      }
      return res.status(200).json(saved);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Admin settings API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
