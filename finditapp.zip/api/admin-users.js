import supabase from './_supabase.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

async function requireAdmin(req, res) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) {
    res.status(401).json({ error: 'Unauthorized' });
    return null;
  }
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    res.status(401).json({ error: 'Invalid token' });
    return null;
  }
  const { data, error: adminError } = await supabase.from('admins').select('*').eq('email', user.email.toLowerCase()).limit(1);
  if (adminError || !data?.length) {
    res.status(403).json({ error: 'Admin access required' });
    return null;
  }
  return { user, admin: data[0] };
}

async function listUsers() {
  const { data: profiles, error } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(200);
  if (error) throw error;

  const { data: reports, error: reportsError } = await supabase
    .from('reports')
    .select('id,reporter_email,status,created_at');
  if (reportsError) throw reportsError;

  const counts = {};
  for (const report of reports || []) {
    if (!report.reporter_email) continue;
    counts[report.reporter_email] = (counts[report.reporter_email] || 0) + 1;
  }

  const { data: admins } = await supabase.from('admins').select('email,role');
  const adminMap = Object.fromEntries((admins || []).map((item) => [item.email, item.role]));

  return (profiles || []).map((profile) => ({
    ...profile,
    reports_count: counts[profile.email] || 0,
    is_admin: Boolean(adminMap[profile.email]),
    admin_role: adminMap[profile.email] || null
  }));
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const auth = await requireAdmin(req, res);
    if (!auth) return;

    if (req.method === 'GET') {
      const users = await listUsers();
      return res.status(200).json(users);
    }

    if (req.method === 'PUT') {
      const payload = req.body || {};
      const id = payload.id;
      if (!id) return res.status(400).json({ error: 'ID user/profile diperlukan' });

      const clean = {
        full_name: String(payload.full_name || '').trim(),
        avatar_url: String(payload.avatar_url || '').trim(),
        whatsapp: String(payload.whatsapp || '').replace(/[^0-9]/g, ''),
        bio: String(payload.bio || '').trim(),
        updated_at: new Date().toISOString()
      };
      if (!clean.full_name) return res.status(400).json({ error: 'Nama user wajib diisi' });

      const { data, error } = await supabase
        .from('profiles')
        .update(clean)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;

      await supabase.from('admin_profile_audit').insert({
        admin_email: auth.user.email.toLowerCase(),
        target_email: data.email,
        action: 'update_profile'
      });

      return res.status(200).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Admin users API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
