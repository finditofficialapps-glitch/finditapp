import supabase from './_supabase.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

async function requireAdmin(req, res) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) {
    res.status(401).json({ error: 'Unauthorized' });
    return null;
  }
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    res.status(401).json({ error: 'Invalid token' });
    return null;
  }
  const { data, error: adminError } = await supabase.from('admins').select('*').eq('email', user.email.toLowerCase()).limit(1);
  if (adminError || !data?.length) {
    res.status(403).json({ error: 'Admin access required. Email Anda belum masuk whitelist.' });
    return null;
  }
  return { user, admin: data[0] };
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const auth = await requireAdmin(req, res);
    if (!auth) return;

    if (req.method === 'GET') {
      const { data, error } = await supabase.from('admins').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json({ admins: data, current: auth.admin });
    }

    if (req.method === 'POST') {
      if (auth.admin.role !== 'superadmin') return res.status(403).json({ error: 'Hanya superadmin yang dapat whitelist admin baru' });
      const email = String(req.body?.email || '').trim().toLowerCase();
      const role = req.body?.role === 'superadmin' ? 'superadmin' : 'admin';
      if (!email || !email.includes('@')) return res.status(400).json({ error: 'Email admin tidak valid' });
      const { data, error } = await supabase.from('admins').insert({ email, role }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'DELETE') {
      if (auth.admin.role !== 'superadmin') return res.status(403).json({ error: 'Hanya superadmin yang dapat menghapus whitelist' });
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'ID admin diperlukan' });
      if (Number(id) === Number(auth.admin.id)) return res.status(400).json({ error: 'Tidak bisa menghapus akun sendiri' });
      const { error } = await supabase.from('admins').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Admins API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
