import supabase from './_supabase.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

async function requireUser(req, res) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) {
    res.status(401).json({ error: 'Login diperlukan' });
    return null;
  }
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    res.status(401).json({ error: 'Token tidak valid' });
    return null;
  }
  return user;
}

async function attachAdminState(profile) {
  if (!profile?.email) return profile;
  const { data, error } = await supabase.from('admins').select('role').eq('email', profile.email.toLowerCase()).limit(1);
  if (error || !data?.length) return { ...profile, is_admin: false, admin_role: null };
  return { ...profile, is_admin: true, admin_role: data[0].role };
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const user = await requireUser(req, res);
    if (!user) return;
    const email = user.email.toLowerCase();

    if (req.method === 'GET') {
      const { data, error } = await supabase.from('profiles').select('*').eq('email', email).limit(1);
      if (error) throw error;
      if (data?.length) return res.status(200).json(await attachAdminState(data[0]));
      const fallbackName = user.user_metadata?.full_name || email.split('@')[0];
      const fallbackAvatar = user.user_metadata?.avatar_url || '';
      const { data: created, error: createError } = await supabase
        .from('profiles')
        .insert({ email, full_name: fallbackName, avatar_url: fallbackAvatar, whatsapp: '', bio: 'Anggota komunitas FindIt' })
        .select()
        .single();
      if (createError) throw createError;
      return res.status(200).json(await attachAdminState(created));
    }

    if (req.method === 'POST' || req.method === 'PUT') {
      const payload = req.body || {};
      const row = {
        email,
        full_name: String(payload.full_name || user.user_metadata?.full_name || email.split('@')[0]).trim(),
        avatar_url: payload.avatar_url || user.user_metadata?.avatar_url || '',
        whatsapp: String(payload.whatsapp || '').replace(/[^0-9]/g, ''),
        bio: String(payload.bio || 'Anggota komunitas FindIt').trim(),
        updated_at: new Date().toISOString()
      };
      const { data: existing, error: findError } = await supabase.from('profiles').select('id').eq('email', email).limit(1);
      if (findError) throw findError;
      if (existing?.length) {
        const { data, error } = await supabase.from('profiles').update(row).eq('email', email).select().single();
        if (error) throw error;
        return res.status(200).json(await attachAdminState(data));
      }
      const { data, error } = await supabase.from('profiles').insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(await attachAdminState(data));
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Profiles API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
