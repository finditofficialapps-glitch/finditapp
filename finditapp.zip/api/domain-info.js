import supabase from './_supabase.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('domain_settings')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1);
      if (error) throw error;
      return res.status(200).json(data?.[0] || { domain: 'findit.zone.id', status: 'configured-in-app' });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Domain info API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
