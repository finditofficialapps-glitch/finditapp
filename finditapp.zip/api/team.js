import supabase from './_supabase.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

async function requireAdmin(req, res) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) { res.status(401).json({ error: 'Unauthorized' }); return null; }
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) { res.status(401).json({ error: 'Invalid token' }); return null; }
  const { data, error: adminError } = await supabase.from('admins').select('*').eq('email', user.email.toLowerCase()).limit(1);
  if (adminError || !data?.length) { res.status(403).json({ error: 'Admin access required' }); return null; }
  return { user, admin: data[0] };
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { all } = req.query;
      let query = supabase.from('team_members').select('*').order('sort_order', { ascending: true }).order('created_at', { ascending: true });
      if (all !== 'true') query = query.eq('active', true);
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    const auth = await requireAdmin(req, res);
    if (!auth) return;

    if (req.method === 'POST') {
      const payload = req.body || {};
      const name = String(payload.name || payload.full_name || '').trim();
      const role = String(payload.role || '').trim();
      if (!name || !role) return res.status(400).json({ error: 'Nama dan role wajib diisi' });
      const row = {
        name,
        role,
        bio: String(payload.bio || '').trim(),
        photo_url: payload.photo_url || '',
        linkedin_url: String(payload.linkedin_url || '').trim(),
        active: payload.active !== false,
        sort_order: Number(payload.sort_order || 1)
      };
      const { data, error } = await supabase.from('team_members').insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, ...updates } = req.body || {};
      if (!id) return res.status(400).json({ error: 'ID anggota tim diperlukan' });
      const clean = {};
      if (updates.name !== undefined || updates.full_name !== undefined) clean.name = updates.name || updates.full_name;
      ['role', 'bio', 'photo_url', 'linkedin_url', 'active', 'sort_order'].forEach((key) => { if (updates[key] !== undefined) clean[key] = updates[key]; });
      clean.updated_at = new Date().toISOString();
      const { data, error } = await supabase.from('team_members').update(clean).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'ID anggota tim diperlukan' });
      const { error } = await supabase.from('team_members').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Team API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
