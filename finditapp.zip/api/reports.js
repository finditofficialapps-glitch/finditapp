import supabase from './_supabase.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

async function getUser(req) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return null;
  const { data, error } = await supabase.auth.getUser(token);
  if (error) return null;
  return data?.user ?? null;
}

async function getAdmin(email) {
  if (!email) return null;
  const { data, error } = await supabase.from('admins').select('*').eq('email', email.toLowerCase()).limit(1);
  if (error || !data?.length) return null;
  return data[0];
}

async function mergeReporterProfiles(reports) {
  const emails = [...new Set((reports || []).map((r) => r.reporter_email).filter(Boolean))];
  if (!emails.length) return reports || [];
  const { data: profiles, error } = await supabase.from('profiles').select('email,full_name,avatar_url,whatsapp,bio').in('email', emails);
  if (error) return reports || [];
  const byEmail = Object.fromEntries((profiles || []).map((p) => [p.email, p]));
  return (reports || []).map((report) => ({
    ...report,
    reporter_avatar: byEmail[report.reporter_email]?.avatar_url || '',
    reporter_profile_name: byEmail[report.reporter_email]?.full_name || report.reporter_name,
    reporter_profile_whatsapp: byEmail[report.reporter_email]?.whatsapp || report.whatsapp
  }));
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { q, category, location, status, limit = '60' } = req.query;
      let query = supabase.from('reports').select('*').order('created_at', { ascending: false }).limit(Math.min(parseInt(limit, 10) || 60, 100));
      if (category && category !== 'Semua') query = query.eq('category', category);
      if (location && location !== 'Semua') query = query.eq('province', location);
      if (status && status !== 'Semua') query = query.eq('status', status);
      if (q) query = query.or(`title.ilike.%${q}%,description.ilike.%${q}%,location.ilike.%${q}%`);
      const { data, error } = await query;
      if (error) throw error;
      const enriched = await mergeReporterProfiles(data || []);
      return res.status(200).json(enriched);
    }

    if (req.method === 'POST') {
      const user = await getUser(req);
      if (!user) return res.status(401).json({ error: 'Login diperlukan sebelum membuat laporan' });
      const payload = req.body || {};
      const required = ['title', 'description', 'category', 'location', 'province', 'status'];
      const missing = required.filter((key) => !String(payload[key] || '').trim());
      if (missing.length) return res.status(400).json({ error: `Field wajib: ${missing.join(', ')}` });
      const email = user.email?.toLowerCase() || '';
      const { data: profileRows } = await supabase.from('profiles').select('*').eq('email', email).limit(1);
      const profile = profileRows?.[0];
      if (!profile?.full_name || !profile?.whatsapp) {
        return res.status(400).json({ error: 'Lengkapi nama dan WhatsApp di pengaturan profile sebelum membuat laporan' });
      }
      const row = {
        title: payload.title.trim(),
        description: payload.description.trim(),
        category: payload.category,
        location: payload.location.trim(),
        province: payload.province,
        status: payload.status,
        reporter_name: profile.full_name,
        reporter_email: email,
        whatsapp: profile.whatsapp,
        image_url: payload.image_url || ''
      };
      const { data, error } = await supabase.from('reports').insert(row).select().single();
      if (error) throw error;
      const enriched = await mergeReporterProfiles([data]);
      return res.status(201).json(enriched[0]);
    }

    if (req.method === 'PUT') {
      const user = await getUser(req);
      if (!user) return res.status(401).json({ error: 'Login diperlukan' });
      const admin = await getAdmin(user.email);
      if (!admin) return res.status(403).json({ error: 'Hanya admin terverifikasi yang dapat mengubah laporan' });
      const { id, ...updates } = req.body || {};
      if (!id) return res.status(400).json({ error: 'ID laporan diperlukan' });
      const allowed = ['title', 'description', 'category', 'location', 'province', 'status', 'reporter_name', 'reporter_email', 'whatsapp', 'image_url'];
      const clean = {};
      allowed.forEach((key) => { if (updates[key] !== undefined) clean[key] = updates[key]; });
      clean.updated_at = new Date().toISOString();
      const { data, error } = await supabase.from('reports').update(clean).eq('id', id).select().single();
      if (error) throw error;
      const enriched = await mergeReporterProfiles([data]);
      return res.status(200).json(enriched[0]);
    }

    if (req.method === 'DELETE') {
      const user = await getUser(req);
      if (!user) return res.status(401).json({ error: 'Login diperlukan' });
      const admin = await getAdmin(user.email);
      if (!admin) return res.status(403).json({ error: 'Hanya admin terverifikasi yang dapat menghapus laporan' });
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'ID laporan diperlukan' });
      const { error } = await supabase.from('reports').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Reports API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
