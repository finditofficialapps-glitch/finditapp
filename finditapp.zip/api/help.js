import supabase from './_supabase.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { slug } = req.query;
      let query = supabase
        .from('help_topics')
        .select('*')
        .order('sort_order', { ascending: true });
      if (slug) query = query.eq('slug', slug).limit(1);
      const { data, error } = await query;
      if (error) throw error;
      if (slug) return res.status(200).json(data?.[0] || null);
      return res.status(200).json(data || []);
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Help API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
