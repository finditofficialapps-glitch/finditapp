import supabase from './_supabase.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

async function requireAdmin(req, res) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) {
    res.status(401).json({ error: 'Unauthorized' });
    return null;
  }
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    res.status(401).json({ error: 'Invalid token' });
    return null;
  }
  const { data, error: adminError } = await supabase.from('admins').select('*').eq('email', user.email.toLowerCase()).limit(1);
  if (adminError || !data?.length) {
    res.status(403).json({ error: 'Admin access required' });
    return null;
  }
  return { user, admin: data[0] };
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const auth = await requireAdmin(req, res);
    if (!auth) return;

    if (req.method === 'PUT') {
      const payload = req.body || {};
      const email = String(payload.email || '').trim().toLowerCase();
      if (!email) return res.status(400).json({ error: 'Email profile diperlukan' });
      const row = {
        full_name: String(payload.full_name || '').trim(),
        avatar_url: payload.avatar_url || '',
        whatsapp: String(payload.whatsapp || '').replace(/[^0-9]/g, ''),
        bio: String(payload.bio || '').trim(),
        updated_at: new Date().toISOString()
      };
      const { data, error } = await supabase.from('profiles').update(row).eq('email', email).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Admin profile API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
