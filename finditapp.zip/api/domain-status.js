import supabase from './_supabase.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const host = String(req.query.host || req.headers.host || '').toLowerCase();
      const { data, error } = await supabase
        .from('custom_domains')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      const current = (data || []).find((item) => item.domain === host || host.includes(item.domain));
      return res.status(200).json({ host, matched: current || null, domains: data || [] });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Domain status API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
