import supabase from './_supabase.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

async function requireAdmin(req, res) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) {
    res.status(401).json({ error: 'Unauthorized' });
    return null;
  }
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    res.status(401).json({ error: 'Invalid token' });
    return null;
  }
  const { data, error: adminError } = await supabase.from('admins').select('*').eq('email', user.email.toLowerCase()).limit(1);
  if (adminError || !data?.length) {
    res.status(403).json({ error: 'Admin access required' });
    return null;
  }
  return { user, admin: data[0] };
}

function rowsToAbout(rows) {
  const map = Object.fromEntries((rows || []).map((row) => [row.key, row.value]));
  return {
    hero_title: map.title || 'Tim kami membangun ekosistem aman untuk barang hilang dan ditemukan.',
    description: map.description || 'FindIt dikelola oleh tim komunitas, moderator, dan relawan digital yang berfokus pada keamanan, verifikasi, serta kemudahan komunikasi antar pengguna di seluruh Indonesia.',
    mission: map.mission || 'Misi kami adalah mempercepat proses menemukan dan mengembalikan barang dengan teknologi komunitas yang aman, transparan, dan mudah digunakan.'
  };
}

async function updateAboutKey(key, value, sortOrder) {
  const { data: existing, error: findError } = await supabase.from('about_content').select('id').eq('key', key).limit(1);
  if (findError) throw findError;
  if (existing?.length) {
    const { error } = await supabase.from('about_content').update({ value, sort_order: sortOrder, updated_at: new Date().toISOString() }).eq('id', existing[0].id);
    if (error) throw error;
  } else {
    const { error } = await supabase.from('about_content').insert({ key, value, sort_order: sortOrder });
    if (error) throw error;
  }
}

async function getAboutPayload() {
  const { data: aboutRows, error: aboutError } = await supabase
    .from('about_content')
    .select('*')
    .order('sort_order', { ascending: true });
  if (aboutError) throw aboutError;

  const { data: team, error: teamError } = await supabase
    .from('team_members')
    .select('*')
    .order('sort_order', { ascending: true });
  if (teamError) throw teamError;

  return { about: rowsToAbout(aboutRows || []), team: team || [] };
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const payload = await getAboutPayload();
      return res.status(200).json(payload);
    }

    const auth = await requireAdmin(req, res);
    if (!auth) return;

    if (req.method === 'PUT') {
      const payload = req.body || {};
      if (payload.type === 'about') {
        await updateAboutKey('title', String(payload.hero_title || '').trim(), 2);
        await updateAboutKey('description', String(payload.description || '').trim(), 3);
        await updateAboutKey('mission', String(payload.mission || '').trim(), 4);
        const fresh = await getAboutPayload();
        return res.status(200).json(fresh.about);
      }

      if (payload.type === 'team') {
        const { id } = payload;
        if (!id) return res.status(400).json({ error: 'ID tim diperlukan' });
        const row = {
          name: String(payload.name || '').trim(),
          role: String(payload.role || '').trim(),
          bio: String(payload.bio || '').trim(),
          photo_url: payload.photo_url || '',
          sort_order: Number(payload.sort_order || 1),
          updated_at: new Date().toISOString()
        };
        const { data, error } = await supabase.from('team_members').update(row).eq('id', id).select().single();
        if (error) throw error;
        return res.status(200).json(data);
      }

      return res.status(400).json({ error: 'Tipe update tidak valid' });
    }

    if (req.method === 'POST') {
      const payload = req.body || {};
      const row = {
        name: String(payload.name || '').trim(),
        role: String(payload.role || '').trim(),
        bio: String(payload.bio || '').trim(),
        photo_url: payload.photo_url || '',
        sort_order: Number(payload.sort_order || 99)
      };
      if (!row.name || !row.role || !row.bio) return res.status(400).json({ error: 'Nama, role, dan bio tim wajib diisi' });
      const { data, error } = await supabase.from('team_members').insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'ID tim diperlukan' });
      const { error } = await supabase.from('team_members').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('About API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
