import supabase from './_supabase.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

async function requireAdmin(req, res) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) {
    res.status(401).json({ error: 'Unauthorized' });
    return null;
  }
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    res.status(401).json({ error: 'Invalid token' });
    return null;
  }
  const { data, error: adminError } = await supabase.from('admins').select('*').eq('email', user.email.toLowerCase()).limit(1);
  if (adminError || !data?.length) {
    res.status(403).json({ error: 'Admin access required' });
    return null;
  }
  return { user, admin: data[0] };
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data: aboutRows, error: aboutError } = await supabase.from('site_about').select('*').order('id', { ascending: true }).limit(1);
      if (aboutError) throw aboutError;
      const { data: team, error: teamError } = await supabase.from('team_members').select('*').order('sort_order', { ascending: true });
      if (teamError) throw teamError;
      return res.status(200).json({ about: aboutRows?.[0] || null, team: team || [] });
    }

    const auth = await requireAdmin(req, res);
    if (!auth) return;

    if (req.method === 'PUT') {
      const { about } = req.body || {};
      if (!about) return res.status(400).json({ error: 'Data tentang diperlukan' });
      const clean = {
        headline: String(about.headline || '').trim(),
        description: String(about.description || '').trim(),
        mission: String(about.mission || '').trim(),
        image_url: String(about.image_url || '').trim(),
        updated_at: new Date().toISOString()
      };
      const { data: existing, error: findError } = await supabase.from('site_about').select('id').order('id', { ascending: true }).limit(1);
      if (findError) throw findError;
      if (existing?.length) {
        const { data, error } = await supabase.from('site_about').update(clean).eq('id', existing[0].id).select().single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      const { data, error } = await supabase.from('site_about').insert(clean).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'POST') {
      const payload = req.body || {};
      const name = String(payload.name || '').trim();
      const role = String(payload.role || '').trim();
      if (!name || !role) return res.status(400).json({ error: 'Nama dan role tim wajib diisi' });
      const row = {
        name,
        role,
        bio: String(payload.bio || '').trim(),
        photo_url: String(payload.photo_url || '').trim(),
        sort_order: Number(payload.sort_order || 10),
        active: payload.active !== false
      };
      const { data, error } = await supabase.from('team_members').insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'ID member diperlukan' });
      const { error } = await supabase.from('team_members').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Site about API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
