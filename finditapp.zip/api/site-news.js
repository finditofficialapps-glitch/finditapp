import supabase from './_supabase.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

async function requireAdmin(req, res) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) {
    res.status(401).json({ error: 'Unauthorized' });
    return null;
  }
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    res.status(401).json({ error: 'Invalid token' });
    return null;
  }
  const { data, error: adminError } = await supabase.from('admins').select('*').eq('email', user.email.toLowerCase()).limit(1);
  if (adminError || !data?.length) {
    res.status(403).json({ error: 'Admin access required' });
    return null;
  }
  return { user, admin: data[0] };
}

async function enrichNews(rows) {
  const ids = (rows || []).map((item) => item.id);
  if (!ids.length) return rows || [];
  const { data: links, error } = await supabase.from('site_news_links').select('*').in('news_id', ids);
  if (error) return rows || [];
  const byNewsId = Object.fromEntries((links || []).map((link) => [link.news_id, link]));
  return (rows || []).map((item) => ({ ...item, link_url: byNewsId[item.id]?.link_url || '', link_label: byNewsId[item.id]?.link_label || 'Baca selengkapnya' }));
}

async function upsertLink(newsId, linkUrl, linkLabel = 'Baca selengkapnya') {
  const cleanUrl = String(linkUrl || '').trim();
  const cleanLabel = String(linkLabel || 'Baca selengkapnya').trim();
  const { data: existing, error: findError } = await supabase.from('site_news_links').select('id').eq('news_id', newsId).limit(1);
  if (findError) throw findError;
  if (existing?.length) {
    const { error } = await supabase.from('site_news_links').update({ link_url: cleanUrl, link_label: cleanLabel, updated_at: new Date().toISOString() }).eq('news_id', newsId);
    if (error) throw error;
  } else {
    const { error } = await supabase.from('site_news_links').insert({ news_id: newsId, link_url: cleanUrl, link_label: cleanLabel });
    if (error) throw error;
  }
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { all } = req.query;
      let query = supabase.from('site_news').select('*').order('created_at', { ascending: false });
      if (all !== 'true') query = query.eq('published', true);
      const { data, error } = await query;
      if (error) throw error;
      const enriched = await enrichNews(data || []);
      return res.status(200).json(enriched);
    }

    const auth = await requireAdmin(req, res);
    if (!auth) return;

    if (req.method === 'POST') {
      const payload = req.body || {};
      const title = String(payload.title || '').trim();
      const excerpt = String(payload.excerpt || '').trim();
      const body = String(payload.body || '').trim();
      if (!title || !excerpt || !body) return res.status(400).json({ error: 'Judul, ringkasan, dan isi berita wajib diisi' });
      const row = {
        title,
        excerpt,
        body,
        category: String(payload.category || 'Info').trim(),
        image_url: payload.image_url || '',
        published: Boolean(payload.published),
        author_email: auth.user.email.toLowerCase()
      };
      const { data, error } = await supabase.from('site_news').insert(row).select().single();
      if (error) throw error;
      await upsertLink(data.id, payload.link_url || '', payload.link_label || 'Baca selengkapnya');
      const enriched = await enrichNews([data]);
      return res.status(201).json(enriched[0]);
    }

    if (req.method === 'PUT') {
      const { id, ...updates } = req.body || {};
      if (!id) return res.status(400).json({ error: 'ID berita diperlukan' });
      const allowed = ['title', 'excerpt', 'body', 'category', 'image_url', 'published'];
      const clean = {};
      allowed.forEach((key) => { if (updates[key] !== undefined) clean[key] = updates[key]; });
      clean.updated_at = new Date().toISOString();
      const { data, error } = await supabase.from('site_news').update(clean).eq('id', id).select().single();
      if (error) throw error;
      if (updates.link_url !== undefined || updates.link_label !== undefined) await upsertLink(id, updates.link_url || '', updates.link_label || 'Baca selengkapnya');
      const enriched = await enrichNews([data]);
      return res.status(200).json(enriched[0]);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'ID berita diperlukan' });
      await supabase.from('site_news_links').delete().eq('news_id', id);
      const { error } = await supabase.from('site_news').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Site news API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
